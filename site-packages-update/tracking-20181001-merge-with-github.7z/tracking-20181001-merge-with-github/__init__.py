VERSION = (0, 4, 1)

__version__ = '.'.join([str(n) for n in VERSION])

